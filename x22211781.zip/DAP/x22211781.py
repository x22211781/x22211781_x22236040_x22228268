import random
import pandas as pd
from sodapy import Socrata
from pymongo import MongoClient


api_tokens = ["eE7mWqdVoeqan4YGQEjXr8me3", "xWIEFa6T0jqLH1FqSFAu64AtI", "CCJYw9OMNbtttSbKye2RhFbJQ"]
dataset_ids = ["bhju-22kf", "mmzv-x632", "n7fk-dce5"]
custom_collection_names = ["incidents_data", "drivers_data", "non_motorist"] 

# MongoDB setup
mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
db = mongo_client['Crash_Reporting']

# Loop through each API
for api_token, dataset_id, collection_name in zip(api_tokens, dataset_ids, custom_collection_names):
    # Socrata API setup
    socrata_client = Socrata('data.montgomerycountymd.gov', api_token)

    # Fetch data from the API
    results = socrata_client.get(dataset_id, limit=2000)

    # Randomly sample 20% of the data (adjust as needed)
    sample_size = int(0.2 * len(results))
    sampled_data = random.sample(results, sample_size)

    # Convert sampled data to a DataFrame
    sampled_df = pd.DataFrame.from_records(sampled_data)

    # Convert DataFrame to a list of dictionaries
    data_to_insert = sampled_df.to_dict(orient='records')

    # Insert sampled data into the specified collection
    collection = db[collection_name]
    collection.insert_many(data_to_insert)

print("Randomly sampled data inserted into specified MongoDB collections successfully.")


# In[3]:


from luigi import LocalTarget, Task
import pandas as pd
from pymongo import MongoClient

class ExtractMongoData(Task):
    def output(self):
        return LocalTarget("incidents_data.csv")

    def run(self):
        # MongoDB setup
        mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
        db = mongo_client['Crash_Reporting']
        collection_name = 'incidents_data'  # Adjust collection name if needed
        collection = db[collection_name]

        try:
            # Extract data from MongoDB
            data_from_mongo = list(collection.find())
            df = pd.DataFrame(data_from_mongo)
            # Save extracted data to a CSV file
            df.to_csv(self.output().path, index=False)
        except Exception as e:
            # Log the error message or handle it accordingly
            print(f"Error occurred while saving CSV: {e}")


# In[4]:


data_from_mongo = list(collection.find())
df = pd.DataFrame(data_from_mongo)
df.head()


# In[5]:


print(df.columns)


# In[6]:


from luigi import LocalTarget, Task, build
import pandas as pd

class TransformData(Task):
    def requires(self):
        return ExtractMongoData()

    def output(self):
        return[
            LocalTarget("incidents_data_new.csv")
        ]
    
    def run(self):
        # reading data from the output of ExtractMongoData
        df = pd.read_csv(self.input().path)    
      
        # Fill missing values with the median of each column
        df.fillna(df.median(), inplace=True)
        
        # check for missing values
        missing_values = df.isnull().sum()

        # finding the column with the most null values
        column_with_most_nulls = df.isnull().sum().idxmax()

        # dropping the column with the most null values
        df.drop(column_with_most_nulls, axis=1, inplace=True)
        
        # removing Duplicates: Identify and remove duplicate rows or columns
        df.drop_duplicates(inplace=True)  
        
        # Transform column names
        new_column_names = {
            '_id': 'record_id',
            'acrs_report_type': 'report_type',
            'crash_date_time': 'crash_datetime',
            'collision_type': 'accident_type'
           
        }
        
        # Drop additional columns
        columns_to_drop = [':@computed_region_vu5j_pcmz', ':@computed_region_tx5f_5em3',
                           ':@computed_region_kbsp_ykn9', ':@computed_region_d7bw_bq6x',
                           ':@computed_region_rbt8_3x7n', ':@computed_region_a9cs_3ed7',
                           ':@computed_region_r648_kzwt', ':@computed_region_6vgr_duib',
                           'off_road_description']
        df.drop(columns=columns_to_drop, inplace=True)

        df.rename(columns=new_column_names, inplace=True)
        
        label_mappings = {
            'Fatal Crash': 0,
            'Injury Crash': 1,
            'Property Damage Crash' : 2,
            'CLEAR' : 0,
            'CLOUDY' : 1,
            'FOGGY' : 2,
            'RAINING' : 3,
            'SNOW' : 4,
            'OTHER' : 5,
            'DARK -- UNKNOWN LIGHTING': 0,
            'DARK LIGHTS ON' : 1,
            'DARK NO LIGHTS' : 2,
            'DAWN' : 3,
            'DAYLIGHT' : 4,
            'DUSK' : 5,
            'OTHER' : 6,
            'FOREIGN MATERIAL' : 0,
            'HOLES RUTS ETC' : 1,
            'LOOSE SURFACE MATERIAL' : 2,
            'NO DEFECTS' : 3,
            'SHOULDER DEFECT' : 4,
            'VIEW OBSTRUCTED':5,
            'OTHER': 6,
        }

        columns_to_encode = ['report_type', 'weather', 'light', 'road_condition' ]  
        for col in columns_to_encode:
            df[col] = df[col].map(label_mappings).fillna(df[col])
         
        # Save the transformed data to another CSV file
        df.to_csv(self.output()[0].path, index=False)

if __name__ == "__main__":
    build([TransformData()], local_scheduler=True)


# In[12]:


from sqlalchemy import create_engine, event, text, exc 
from sqlalchemy.engine.url import URL
from sqlalchemy import create_engine, exc
import pandas.io.sql as sqlio 
import luigi

class LoadTask(luigi.Task):
    connection_string = "postgresql+psycopg2://Sayan:sayan16@127.0.0.1:5432/postgres"
    csv_file_path = 'incidents_data_new.csv'

    def create_database(self):
        try:
            engine = create_engine(self.connection_string)
            with engine.connect() as connection:
                connection.execution_options(isolation_level="AUTOCOMMIT")
                connection.execute(text("DROP DATABASE IF EXISTS crash_incident_db;"))
                connection.execute(text("CREATE DATABASE crash_incident_db;"))
        except exc.SQLAlchemyError as dbError:
            print("PostgreSQL Error", dbError)
        finally:
            if 'connection' in locals():
                connection.close()

    def run(self):
        # Create the database
        self.create_database()

        # Create SQLAlchemy engine for the new database
        new_connection_string = self.connection_string[:-8] + 'crash_incident_db'
        engine = create_engine(new_connection_string)

        # Read the CSV file into a Pandas DataFrame
        df = pd.read_csv(self.csv_file_path)

        # Export the DataFrame to PostgreSQL
        try:
            df.to_sql('crash_reporting_table', engine, if_exists='replace', index=False)
            print("CSV file imported successfully to PostgreSQL!")
        except Exception as e:
            print("Error importing CSV to PostgreSQL:", e)

    def output(self):
        # Define the output of the LoadTask if necessary
        # For example, return a luigi.LocalTarget
        pass
if __name__ == '__main__':
    tasks = [ExtractMongoData(), TransformData(), LoadTask()]
    luigi.build(tasks, local_scheduler=True)


# In[18]:


from sqlalchemy import create_engine, text, exc
import pandas.io.sql as sqlio 

query_string = """
    SELECT * 
    FROM crash_reporting_table;
    """

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        Crash_data = sqlio.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()


# In[19]:


Crash_data.head()


# In[21]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# Your connection string and other setup

query_string = """
    SELECT report_type, accident_type, COUNT(*) AS count
    FROM crash_reporting_table
    GROUP BY report_type, accident_type
    ORDER BY report_type, count DESC;
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        crash_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()

plt.figure(figsize=(12, 6))
sns.barplot(x='report_type', y='count', hue='accident_type', data=crash_dataframe)
plt.title('Crash Severity and Type Analysis')
plt.xlabel('Report Type')
plt.ylabel('Count')
plt.xticks(rotation=90)  # Rotates x-axis labels for better readability
plt.legend(title='Accident Type')
plt.tight_layout()
plt.show()


# In[22]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# Your connection string and other setup

query_string = """
    SELECT weather, light, road_condition, COUNT(*) AS count
    FROM crash_reporting_table
    GROUP BY weather, light, road_condition
    ORDER BY count DESC;
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        conditions_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()

# Plot the data
plt.figure(figsize=(12, 6))
sns.barplot(x='weather', y='count', hue='light', data=conditions_dataframe)
plt.title('Crash Count Based on Environmental and Road Conditions')
plt.xlabel('Weather')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='Light Conditions')
plt.tight_layout()
plt.show()


# In[23]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# Your connection string and other setup

query_string = """
    SELECT CAST(crash_datetime AS DATE) AS crash_date, COUNT(*) AS count
    FROM crash_reporting_table
    GROUP BY crash_date
    ORDER BY crash_date;
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        time_location_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()

# Convert crash_date to a datetime format
time_location_dataframe['crash_date'] = pd.to_datetime(time_location_dataframe['crash_date'])

# Plot the data
plt.figure(figsize=(12, 6))
sns.lineplot(x='crash_date', y='count', data=time_location_dataframe)
plt.title('Crash Count Over Time')
plt.xlabel('Crash Date')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# In[ ]:




