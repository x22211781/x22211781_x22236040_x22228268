db.createUser(
        {
            user: "<Sayan.16>",
            pwd: "<Saiyan2023>",
            roles: [
                {
                    role: "readWrite",
                    db: "dap"
                }
            ]
        }
);
