db.createUser(
        {
            user: "<dhruv13200>",
            pwd: "<dhruv132>",
            roles: [
                {
                    role: "readWrite",
                    db: "dap"
                }
            ]
        }
);
