import random
import pandas as pd
from sodapy import Socrata
from pymongo import MongoClient

api_tokens = ["xWIEFa6T0jqLH1FqSFAu64AtI"]
dataset_ids = ["mmzv-x632"]
custom_collection_names = ["drivers_data"] 

# MongoDB setup
mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
db = mongo_client['Crash_Reporting']

# Loop through each API
for api_token, dataset_id, collection_name in zip(api_tokens, dataset_ids, custom_collection_names):
    # Socrata API setup
    socrata_client = Socrata('data.montgomerycountymd.gov', api_token)

    # Fetch data from the API
    results = socrata_client.get(dataset_id, limit=10000)

    # Randomly sample 20% of the data (adjust as needed)
    sample_size = int(0.2 * len(results))
    sampled_data = random.sample(results, sample_size)

    # Convert sampled data to a DataFrame
    sampled_df = pd.DataFrame.from_records(sampled_data)

    # Convert DataFrame to a list of dictionaries
    data_to_insert = sampled_df.to_dict(orient='records')

    # Insert sampled data into the specified collection
    collection = db[collection_name]
    collection.insert_many(data_to_insert)

print("Randomly sampled data inserted into specified MongoDB collections successfully.")


from luigi import LocalTarget, Task , build

class ExtractMongoData(Task):
    def output(self):
        return LocalTarget("drivers_data.csv")

    def run(self):
        # MongoDB setup
        mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
        db = mongo_client['Crash_Reporting']
        collection_name = 'drivers_data' 
        collection = db[collection_name]

        try:
            # Extract data from MongoDB
            data_from_mongo = list(collection.find())
            df = pd.DataFrame(data_from_mongo)
            # Save extracted data to a CSV file
            df.to_csv(self.output().path, index=False)
            
        except Exception as e:
            # Log the error message or handle it accordingly
            print(f"Error occurred while saving CSV: {e}")


# In[10]:


data_from_mongo = list(collection.find())
df = pd.DataFrame(data_from_mongo)
df.head()
print(df.shape)


# In[11]:


print(df.columns)


# In[12]:


import os
class TransformData(Task):
    def requires(self):
        return ExtractMongoData()

    def output(self):
        return[
            LocalTarget("drivers_data_new.csv")
        ]
    
    def run(self):
        # Remove the output file if it exists
        output_path = self.output()[0].path
        if os.path.exists(output_path):
            logging.info(f"Removing existing output file: {output_path}")
            os.remove(output_path)
        
        # reading data from the output of ExtractMongoData
        df = pd.read_csv(self.input().path)
        
        # finding the column with the most null values
        column_with_most_nulls = df.isnull().sum().idxmax()
        

        # dropping the column with the most null values
        df.drop(column_with_most_nulls, axis=1, inplace=True)
        
        columns_to_keep = ['report_number','driver_substance_abuse', 'driver_at_fault',
                           'speed_limit','injury_severity', 'driver_distracted_by']

        
        df=df.loc[:,columns_to_keep].copy()
      
        # Fill missing values with the median of each column
        df.dropna(inplace=True)
        
        # removing Duplicates: Identify and remove duplicate rows or columns
        df.drop_duplicates(inplace=True)
        
        df.to_csv(self.output()[0].path, index=False)

if __name__ == "__main__":
    build([TransformData()], local_scheduler=True)


# In[13]:


from sqlalchemy import create_engine, event, text, exc
from sqlalchemy.engine.url import URL
from sqlalchemy import create_engine, exc
import pandas as pd
import pandas.io.sql as sqlio
import luigi
 
class LoadTask(luigi.Task):
    connection_string = "postgresql+psycopg2://dhruv13200:dhruv132@127.0.0.1:5432/postgres"
    csv_file_path = 'drivers_data_new.csv'
 
    def create_database(self):
        try:
            engine = create_engine(self.connection_string)
            with engine.connect() as connection:
                connection.execution_options(isolation_level="AUTOCOMMIT")
                connection.execute(text("DROP DATABASE IF EXISTS crash_reporting_db;"))
                connection.execute(text("CREATE DATABASE crash_reporting_db;"))
        except exc.SQLAlchemyError as dbError:
            print("PostgreSQL Error", dbError)
        finally:
            if 'connection' in locals():
                connection.close()
 
    def run(self):
        # Create the database
        self.create_database()
 
        # Create SQLAlchemy engine for the new database
        new_connection_string = self.connection_string[:-8] + 'crash_reporting_db'
        engine = create_engine(new_connection_string)
 
        # Read the CSV file into a Pandas DataFrame
        df = pd.read_csv(self.csv_file_path)
 
        # Export the DataFrame to PostgreSQL
        try:
            df.to_sql('crash reporting', engine, if_exists='replace', index=False)
            print("File imported successfully to PostgreSQL!")
        except Exception as e:
            print("Error importing file to PostgreSQL:", e)
 
    def output(self):
        # Define the output of the LoadTask if necessary
        # For example, return a luigi.LocalTarget
        pass
 
if __name__ == '__main__':
    tasks = [LoadTask()]
    luigi.build(tasks, local_scheduler=True)


# In[16]:


query_string = """
    SELECT * 
    FROM crash_reporting_table;
    """

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        Crash_data = sqlio.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()


# In[17]:


Crash_data.head()


# In[18]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# Your connection string and other setup

query_string = """
    SELECT count(report_number) as count,driver_substance_abuse
    FROM crash_reporting_table
    group by driver_substance_abuse
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        crash_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()


plt.figure(figsize=(12, 6))

#removing values which are irrelevant for insight
values=['N/A','UNKNOWN','NONE DETECTED']
sns.barplot(x='driver_substance_abuse', y='count', data=crash_dataframe[~crash_dataframe.driver_substance_abuse.isin(values)])
plt.title('Identified causes contribution to crashes')
plt.xlabel('Potential Cause')
plt.ylabel('Frequency')
plt.xticks(rotation=90)  # Rotates x-axis labels for better readability
plt.tight_layout()
plt.show()


# In[19]:


crash_dataframe.count


# In[20]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# Your connection string and other setup

query_string = """
    SELECT driver_at_fault,count(*)
    FROM crash_reporting_table group by driver_at_fault
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        crash_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()


plt.pie(crash_dataframe['count'], labels=crash_dataframe['driver_at_fault'], autopct='%1.1f%%', startangle=90)
plt.title('Proportion of driver\'s fault in total crashes')
plt.show()


# In[22]:


import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import create_engine, text, exc
import pandas as pd

# connection string and other setup

query_string = """
    SELECT count(report_number) as count,driver_distracted_by
    FROM crash_reporting_table
    group by driver_distracted_by
"""

try:
    engine = create_engine(LoadTask.connection_string)
    with engine.connect() as connection:
        crash_dataframe = pd.read_sql_query(text(query_string), connection)
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()


plt.figure(figsize=(12,12))
values=['NOT DISTRACTED','UNKNOWN','LOOKED BUT DID NOT SEE']
#removing values which are irrelevant for insight
sns.barplot(x='driver_distracted_by', y='count', data=crash_dataframe[~crash_dataframe.isin(values)])
plt.title('Frequency of distracting causes in accidents')
plt.xlabel('Causes of Distraction')
plt.ylabel('Frequency')
plt.xticks(rotation=90)  
plt.tight_layout()
plt.show()


# In[23]:


sns.barplot(x='driver_distracted_by', y='count', data=crash_dataframe[crash_dataframe.driver_distracted_by.isin(values)])
plt.title('Frequency of distracting causes in accidents')
plt.xlabel('Causes of Distraction')
plt.ylabel('Frequency')
plt.xticks(rotation=90)  
plt.tight_layout()
plt.show()

