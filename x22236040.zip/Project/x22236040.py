import random
import pandas as pd
from sodapy import Socrata
from pymongo import MongoClient

#API tokens and dataset IDs
api_tokens = ["eE7mWqdVoeqan4YGQEjXr8me3", "xWIEFa6T0jqLH1FqSFAu64AtI", "CCJYw9OMNbtttSbKye2RhFbJQ"]
dataset_ids = ["bhju-22kf", "mmzv-x632", "n7fk-dce5"]
custom_collection_names = ["incidents_data", "drivers_data", "non_motorist"] 

# MongoDB setup
mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
db = mongo_client['Crash_Reporting']

# Loop through each API
for api_token, dataset_id, collection_name in zip(api_tokens, dataset_ids, custom_collection_names):
    # Socrata API setup
    socrata_client = Socrata('data.montgomerycountymd.gov', api_token)

    # Fetch data from the API
    results = socrata_client.get(dataset_id, limit=2000)

    # Randomly sample 20% of the data (adjust as needed)
    sample_size = int(0.2 * len(results))
    sampled_data = random.sample(results, sample_size)

    # Convert sampled data to a DataFrame
    sampled_df = pd.DataFrame.from_records(sampled_data)

    # Convert DataFrame to a list of dictionaries
    data_to_insert = sampled_df.to_dict(orient='records')

    # Insert sampled data into the specified collection
    collection = db[collection_name]
    collection.insert_many(data_to_insert)

print("Randomly sampled data inserted into specified MongoDB collections successfully.")



from luigi import LocalTarget, Task
import pandas as pd
from pymongo import MongoClient

class ExtractMongoData(Task):
    def output(self):
        return LocalTarget("non_motorist.csv")

    def run(self):
        # MongoDB setup
        mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
        db = mongo_client['Crash_Reporting']
        collection_name = 'non_motorist'
        collection = db[collection_name]

        try:
            # Extract data from MongoDB
            data_from_mongo = list(collection.find())
            df = pd.DataFrame(data_from_mongo)
            # Save extracted data to a CSV file
            df.to_csv(self.output().path, index=False)
        except Exception as e:
            # Log the error message or handle it accordingly
            print(f"Error occurred while saving CSV: {e}")


data_from_mongo = list(collection.find())
df = pd.DataFrame(data_from_mongo)
df.head()




print(df.columns)


# TRANSFORMATION




from luigi import LocalTarget, Task, build
import pandas as pd

class TransformData(Task):
    def requires(self):
        return ExtractMongoData()

    def output(self):
        return LocalTarget("non_motorist_transformed.csv")

    def run(self):
        # Reading data from the output of ExtractMongoData
        df = pd.read_csv(self.input().path)

        # Selecting relevant columns
        relevant_columns = ['report_number', 'crash_date_time', 'agency_name', 'route_type', 'collision_type',
                             'weather', 'surface_condition', 'traffic_control', 'driver_substance_abuse',
                             'non_motorist_substance_abuse', 'pedestrian_type', 'pedestrian_movement',
                             'pedestrian_actions', 'pedestrian_location', 'pedestrian_obeyed_traffic_signal',
                             'pedestrian_visibility', 'at_fault', 'injury_severity']

        df = df[relevant_columns]

        # Fill missing values with the median of each column
        df.fillna(df.median(), inplace=True)

        # Drop duplicates
        df.drop_duplicates(inplace=True)

        # Save the transformed data to another CSV file
        df.to_csv(self.output().path, index=False)

if __name__ == "__main__":
    build([TransformData()], local_scheduler=True)


#  LOADING OF NON MOTORIST DATA INTO POSTGRES




from sqlalchemy import create_engine, event, text, exc 
from sqlalchemy.engine.url import URL
from sqlalchemy import create_engine, exc
import pandas.io.sql as sqlio 
import luigi
 
class LoadTask(luigi.Task):
    connection_string = "postgresql+psycopg2://dap:dap@127.0.0.1:5432/postgres"
    csv_file_path = 'non_motorist_transformed.csv'
 
    def create_database(self):
        try:
            engine = create_engine(self.connection_string)
            with engine.connect() as connection:
                connection.execution_options(isolation_level="AUTOCOMMIT")
                connection.execute(text("DROP DATABASE IF EXISTS crash_incident_db;"))
                connection.execute(text("CREATE DATABASE crash_incident_db;"))
        except exc.SQLAlchemyError as dbError:
            print("PostgreSQL Error", dbError)
        finally:
            if 'connection' in locals():
                connection.close()
 
    def run(self):
        # Create the database
        self.create_database()
 
        # Create SQLAlchemy engine for the new database
        new_connection_string = self.connection_string[:-8] + 'crash_incident_db'
        engine = create_engine(new_connection_string)
 
        # Read the CSV file into a Pandas DataFrame
        df = pd.read_csv(self.csv_file_path)
 
        # Export the DataFrame to PostgreSQL
        try:
            df.to_sql('crash_reporting_table', engine, if_exists='replace', index=False)
            print("CSV file imported successfully to PostgreSQL!")
        except Exception as e:
            print("Error importing CSV to PostgreSQL:", e)
 
    def output(self):
        # Define the output of the LoadTask if necessary
        # For example, return a luigi.LocalTarget
        pass
if __name__ == '__main__':
    tasks = [ExtractMongoData(), TransformData(), LoadTask()]
    luigi.build(tasks, local_scheduler=True)


from sqlalchemy import create_engine, text, exc
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Define your connection string
connection_string = "postgresql+psycopg2://dap:dap@127.0.0.1:5432/crash_incident_db"

# Replace 'crash_reporting_table' and 'route_type', 'collision_type', 'injury_severity' with your actual table and column names
query_route_type = """
    SELECT route_type, collision_type, injury_severity
    FROM crash_reporting_table;
"""

# Execute the query and fetch the results
try:
    engine = create_engine(connection_string)
    with engine.connect() as connection:
        result = connection.execute(text(query_route_type))
        df_route_type = pd.DataFrame(result.fetchall(), columns=result.keys())
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()

# Set up the Matplotlib figure
plt.figure(figsize=(12, 8))

# Plot the distribution of incidents across different route types and collision types
sns.countplot(x='route_type', hue='collision_type', data=df_route_type)

# Add titles and labels
plt.title('Distribution of Incidents by Route Type and Collision Type')
plt.xlabel('Route Type')
plt.ylabel('Number of Incidents')

# Show the plot
plt.show()


# Influence of Traffic Control on Non-Motorist Safety



query_traffic_control = """
    SELECT traffic_control, injury_severity, at_fault
    FROM crash_reporting_table;
"""

# Execute the query and fetch the results
try:
    engine = create_engine(connection_string)
    with engine.connect() as connection:
        result_traffic_control = connection.execute(text(query_traffic_control))
        df_traffic_control = pd.DataFrame(result_traffic_control.fetchall(), columns=result_traffic_control.keys())
except exc.SQLAlchemyError as dbError:
    print("PostgreSQL Error", dbError)
finally:
    if 'engine' in locals():
        engine.dispose()

plt.figure(figsize=(12, 8))

# Plot the relationship between traffic control, injury severity, and whether the non-motorist was at fault
ax = sns.countplot(x='traffic_control', hue='injury_severity', data=df_traffic_control, palette='muted', dodge=True)

# Rotate x-labels for better readability
ax.set_xticklabels(ax.get_xticklabels(), rotation=45, horizontalalignment='right')

# Add titles and labels
plt.title('Influence of Traffic Control on Non-Motorist Safety')
plt.xlabel('Traffic Control')
plt.ylabel('Number of Incidents')

# Show the plot
plt.show()

