# etl_pipeline.py

from dagster import solid, pipeline, ModeDefinition
import pandas as pd
from pymongo import MongoClient


@solid
def extract_crash_data(context):
    # Assuming 'Crash_Reporting_Collection_3' contains your data
    collection_name = 'Crash_Reporting_Collection_3'
    collection = db[collection_name]

    # Query all documents in the collection
    cursor = collection.find()
    data = list(cursor)

    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    context.log.info(f"Extracted {len(df)} records from MongoDB.")
    return df

@solid
def transform_crash_data(context, df):
    # Example transformation: Add a new column 'is_weekend'
    df['is_weekend'] = df['crash_date_time'].dt.day_name().isin(['Saturday', 'Sunday'])
    
    context.log.info("Transformed data.")
    return df

@solid
def load_crash_data(context, df):
    # In a real-world scenario, you might load data into PostgreSQL or another database
    # For simplicity, log the transformed data in this example
    context.log.info("Loaded data to destination.")
    context.log.info(df.head())

# Define the pipeline
@pipeline(mode_defs=[ModeDefinition(resource_defs={'mongo_db': db})])
def crash_etl_pipeline():
    data = extract_crash_data()
    transformed_data = transform_crash_data(data)
    load_crash_data(transformed_data)

if __name__ == "__main__":
    # You can execute the pipeline using the following command:
    # dagit -f etl_pipeline.py
    pass
