from pymongo import MongoClient
from dagster import op, Out, In, DagsterType
from dagster_pandas import PandasColumn, create_dagster_pandas_dataframe_type
from datetime import datetime
import pandas as pd
from dagster import solid, pipeline, ModeDefinition


@solid
def extract_from_mongo(context):
    # MongoDB setup
    mongo_client = MongoClient("mongodb://dap:dap@127.0.0.1")
    db = mongo_client['Crash_Reporting']

    # Assuming 'Crash_Reporting_Collection_3' contains your data
    collection_name = 'Crash_Reporting_Collection_3'
    collection = db[collection_name]

    # Extract data from MongoDB
    data_from_mongo = list(collection.find())
    df = pd.DataFrame(data_from_mongo)
    
    context.log.info(f"Extracted {len(df)} records from MongoDB.")
    return df

@pipeline(mode_defs=[ModeDefinition(resource_defs={'mongo_db': db})])
def mongo_extraction_pipeline():
    extracted_data = extract_from_mongo()
    # Add additional solids or logic here if needed
    # ...

if __name__ == "__main__":
    # You can execute the pipeline using the following command:
    # dagit -f mongo_extraction.py
    pass
